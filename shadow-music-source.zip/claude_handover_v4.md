# Shadow Music - Technical Handover & Bug Review

Hey Claude! We are building a React-based music player called "Shadow Music" and wrapping it into a native Android APK using Capacitor. The user is running the app on a lower-end device (4GB RAM). 

We would love your expert help reviewing the codebase and solving a few specific architectural issues we've run into.

---

### 1. Firebase Authentication Issue (WebView Storage Partitioning)
**The Context:** The app uses Firebase Auth for Google Sign-in. 
**The Problem:** Because modern Android System WebViews (where Capacitor runs) now enforce strict storage partitioning, `signInWithRedirect` completely fails when redirecting back to the app. It throws a `"missing initial state"` error because `sessionStorage` is cleared across the domain boundary. 
**Our Band-Aid:** We temporarily bypassed this by adding a "Continue as Guest" button that hardcodes a dummy user state in `AuthContext.jsx`.
**What we need from you:** Is there any reliable workaround to make Firebase Web Auth (`signInWithRedirect` or `signInWithPopup`) work inside a Capacitor Android WebView *without* having to use the native `@capacitor-firebase/authentication` plugin? (The user cannot configure SHA-1 keys in the Firebase console right now, so native Google Sign-in setup is currently off the table).

### 2. Instant Crash on App Resume (Media Session)
**The Context:** We are using `jofr-capacitor-media-session` to show media controls in the Android notification drawer when a song is playing.
**The Problem:** The app works perfectly on the first launch. However, if the user plays a song, closes the app (sending it to the background), and then tries to open it again, the app *instantly hard crashes* before the splash screen even renders. It seems the OS is failing to cleanly resume or reconnect to the "ghost" media service in the background.
**What we need from you:** Can you suggest a bulletproof way to handle the Capacitor app lifecycle or background audio so it gracefully resumes or terminates without crashing the `MainActivity`?

### 3. App Performance & Smoothness Optimization
**The Context:** The user is on a standard 4GB RAM phone. We aren't worried about the APK download size (standard app sizes are fine), but we *are* hyper-focused on making the app feel incredibly fast, smooth, and responsive.
**What we need from you:** What are your top recommendations for optimizing React and Capacitor performance so the app feels natively fast without any lag or stuttering? Are there specific Vite build flags, Android Webview optimizations, or React rendering patterns we should implement to make the animations and transitions perfectly smooth?

### 4. How We Are Building the APK (Context)
Because the user cannot run Android Studio locally due to hardware constraints, we are building the APK 100% in the cloud using **GitHub Actions**. 
Our workflow (`android.yml`):
- Runs on `ubuntu-latest`.
- Uses Node 22 (`npm ci` -> `npm run build` -> `npx cap sync android`).
- Sets up JDK 21.
- Runs `bash ./gradlew assembleDebug` (we use `bash` because Windows-to-Linux Git uploads occasionally stripped executable permissions from the `gradlew` file).
- Uploads the resulting `app-debug.apk` as a downloadable artifact.

### 5. Detailed Bug List (From the User)
The user has reported the following list of bugs and UI glitches while testing the app on their phone. We need to systematically address these:

**UI & Layout Issues:**
1. **Top Screen Cutoff:** The top of the app is slightly cut off (likely a safe-area or status bar overlap issue in Capacitor).
2. **Bottom Padding:** When scrolling to the bottom of an Artist page, the last song is cut in half (likely obscured by the persistent mini-player).
3. **Mini-Player Transitions:** Opening the full player makes the album photo scale weirdly ("small large and does not look good") - likely an issue with `object-fit` or CSS transition values.
4. **Drag-to-Close Glitch:** Swiping down to close the full-screen player is extremely slow and glitchy on this lower-end device. Needs performance optimization (maybe use Framer Motion or native gestures better).

**Functional Bugs:**
5. **Empty Playlist Crash:** Opening a newly created, empty playlist shows a blank screen/breaks the app. Needs proper empty-state handling.
6. **Playlist Cover Upload:** Uploading a photo to a playlist fails. (This is likely due to Firebase Storage failing because the user is currently using the "Guest Bypass", but we should double-check the image picker code).
7. **Lyrics Toggle:** The user wants a "Show Less" / "Show More" toggle for lyrics rather than displaying them all at once.
8. **Continue Listening:** The user wants the ability to remove/delete songs from their "Continue Listening" history.
9. **Search Page "Moods":** The mood cards on the search page are confusing/non-functional. 

**Native Media Session / Notification Bar Issues:**
10. **Notification Bar Crashes:** Interacting with the Android notification media controls (play/pause/skip) causes the app to crash, especially after using the app for a while.
11. **Lockscreen Controls:** The media controls do not show up on the lock screen until the phone is unlocked. 

**Architecture Feedback:**
12. **Hardcoded Data:** The user noticed we are still relying heavily on the static `data.js` file for songs/photos and wants to completely remove it to fix potential bloating and dynamic loading issues.

---

Please review this extensive list and let us know your plan of attack to fix these bugs and stabilize the app's performance!
